# CryptoCalculator
Calculates the value of your current crypto assets

Please setup the project into your IDE using the following steps:
1. Clone the repo using git clone <project URL>
2. Import the project into intellij as a maven project
3. Run the command "mvn clean install"
4. Write the crypto.txt with your current crypto details
5. Right click on the crypto.java and click on run.
6. A new file will be created with the name totalAssets.txt with the current value of your cryptos.
